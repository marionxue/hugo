octocat, squirrel, shipit
Copyright (c) 2012 GitHub Inc. All rights reserved.

bowtie, neckbeard
Copyright (c) 2012 37signals, LLC. All rights reserved.

feelsgood, finnadie, goberserk, godmode, hurtrealbad, rage 1-4, suspect
Copyright (c) 2012 id Software. All rights reserved.

trollface
Copyright (c) 2012 whynne@deviantart. All rights reserved.

All other images
Copyright (c) 2012 Apple Inc. All rights reserved.
